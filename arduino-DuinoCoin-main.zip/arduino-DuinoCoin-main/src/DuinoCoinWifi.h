#ifndef _DuinoCoinWifi_H_
#define _DuinoCoinWifi_H_
/*
#include <Arduino.h>
#include <ArduinoUniqueID.h>

#if defined(ARDUINO_ARCH_AVR)
#include "avr/sha1.h"
#elif defined(ARDUINO_ARCH_ESP8266)
#include "esp8266/ducos1a.h"
#else
#include "avr/sha1.h"
#endif

class DuinoCoinWifi
{
public:
  DuinoCoinWifi(HardwareSerial &stream);
  ~DuinoCoinWifi();

  void begin();
  bool loop();

  void test(Stream &stream);

  uint32_t ducos1a(String lastblockhash, String newblockhash, int difficulty);

private:
  HardwareSerial &serial;
  String ID;
};
*/
#endif
